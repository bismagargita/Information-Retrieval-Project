<?php
Class Mnlp extends CI_Model{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
	}
	
	public function Select(){
		return
		$this->db->
		select('judul, harga, id_barang')->
		from('produk')->
		order_by('harga','asc')->
		get()->result();
		//SELECT id_barang, judul, harga, deskripsi FROM produk
	}
}
?>