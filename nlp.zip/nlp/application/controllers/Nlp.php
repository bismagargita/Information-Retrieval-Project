<?php
Class Nlp extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$this->load->model('mnlp');
		$this->load->helper('url');
	}
	
	function index(){
		$this->search($this->input->get('search'));
	}
	
	function search($keyword){
		//echo $keyword . '</br>';
		
		$barang = $this->mnlp->select();
		$str = explode(' ',$keyword);
		
		for($i=0;$i<count($barang);$i++){
			$list[$i] = $this->explode($barang[$i]->judul);
		}
		
		$daftarbarang = array();
		for($x=0;$x<count($list);$x++){
			if ($this->vectorization($this->push($str,$list[$x]),$str,$list[$x]) > 0.6){
				//echo $barang[$x]->judul . ' removed </br></br>';
				array_push($daftarbarang,$barang[$x]);
			}
		}
		
		$data = array(
			'daftarbarang' => $daftarbarang,
			'keyword' => $keyword
		);
		
		$this->load->view('index', $data);
		
		//echo json_encode($a);
		//echo '<br><br>';
		//echo json_encode($list);
	}
	
	function similarity($pattern1,$pattern2){
		$similarity = 0;
		$sqrt1 = 0;
		$sqrt2 = 0;
		
		for($x=0;$x<count($pattern1);$x++){
			$similarity += ($pattern1[$x][1] * $pattern2[$x][1]);
		}
		
		foreach($pattern1 as $key=>$value){
			$sqrt1 += $value[1];
		}
		foreach($pattern2 as $key=>$value){
			$sqrt2 += $value[1];
		}
		
		$similarity /= (sqrt($sqrt1) * sqrt($sqrt2));
		//$similarity = cos($similarity);
		
		echo '</br>';
		echo 'similarity = ' . $similarity . '</br></br>';
		
		return $similarity;
	}
	
	function vectorization($pattern,$str,$str2){
		$a = $pattern;
		$b = $pattern;
		
		for($x=0;$x<count($pattern);$x++){
			for($y=0;$y<count($str);$y++){
				if(strcasecmp($str[$y],$pattern[$x][0]) == 0){
					$a[$x][1] += 1;
				}
			}
		}
		
		for($x=0;$x<count($pattern);$x++){
			for($y=0;$y<count($str2);$y++){
				if(strcasecmp($str2[$y],$pattern[$x][0]) == 0){
					$b[$x][1] += 1;
				}
			}
		}
		
		echo json_encode($a);
		echo '</br>';
		echo json_encode($b);
		
		$similarity = $this->similarity($a,$b);
		
		return $similarity;
	}
	
	function push($str,$str2){
		$a = array();
		for($i=0;$i<count($str);$i++){
			$bool = true;
			for($j=0;$j<count($a);$j++){
				if(strcasecmp($str[$i],$a[$j][0]) == 0){
					$bool = false;
				}
			}
			if($bool == true){
				$a[$i][0] = $str[$i];
				$a[$i][1] = 0;
			}
		}
		$idx = count($a);
		for($i=0;$i<count($str2);$i++){
			$bool = true;
			for($j=0;$j<count($a);$j++){
				if(strcasecmp($str2[$i],$a[$j][0]) == 0){
					$bool = false;
				}
			}
			if($bool == true){
				$a[$idx][0] = $str2[$i];
				$a[$idx][1] = 0;
				$idx++;
			}
		}
		return $a;
	}
	
	function explode($str){
		return explode(' ',$str);
	}
}

?>